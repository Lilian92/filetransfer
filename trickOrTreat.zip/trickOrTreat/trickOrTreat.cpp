#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <vector>
#include <fstream>

#ifdef WITH_OPENMP
#include <omp.h>
#endif

using namespace std;

using candy_t = uint32_t;

typedef struct HouseBlock {
    candy_t sum;
    size_t start;
    size_t end;
} HouseBlock;

//define max HouseBlock for reduction
HouseBlock maxHouseBlock(HouseBlock r, HouseBlock n) {
    // r is the already reduced value
    // n is the new value
    HouseBlock m;
    if (n.sum > r.sum) {
        m = n;
    } else if(n.sum < r.sum){
        m = r;
    } else {
        m = n.start < r.start ? n : r;
    }
    return m;
}

#ifdef WITH_OPENMP

//For openmp, max operator
#pragma omp declare reduction \
    (maxOpt:HouseBlock:omp_out=maxHouseBlock(omp_out,omp_in)) \
initializer(omp_priv={0, 0, 0})

#endif

//input data and data legal checking
void inputData(string fileName, vector<candy_t> & pieces,
               candy_t & maximumLimit) {
    size_t homes = 0;

    ifstream inputfile(fileName.c_str());

    //checking whether file is opened correctly
    if (!inputfile.is_open()) {
        cerr << "open input file failed" << endl;
        exit(1);
    }

    //input homes
    inputfile >> homes;
    //NOTE: homes is unsigned, so all values <= 10,000 are okay
    if (inputfile.eof() || homes > 10000) {
        cerr << "illegal homes input" << endl;
        exit(1);
    }

    //input maximum limitation
    inputfile >> maximumLimit;
    // NOTE: similarly maximumLimit is unsigned
    if (inputfile.eof() || maximumLimit > 1000) {
        cerr << "illegal maximumLimit input" << endl;
        exit(1);
    }

    //input remainder of file into pieces
    pieces.resize(homes);
    for (auto piece = pieces.begin(); piece != pieces.end(); piece++) {
        inputfile >> *piece;
        // NOTE: similarly piece is unsigned
        if (inputfile.eof() || *piece > 1000) {
            cerr << "illegal pieces input or too few pieces" << endl;
            exit(1);
        }
    }

    //ensure there is nothing left in the file
    //begin by trimming \n then \r
    while (inputfile.get() == '\n') { }
    while (inputfile.get() == '\r') { }
    if (!inputfile.eof()) {
        cerr << "illegal input file, more pieces than specified" << endl;
        exit(1);
    }

    inputfile.close();
    return;
}


//with all elements in array being bigger or equal to zero
//find the first(start earliest) sub arrary that is smaller or equal, and
//also closest to maximum limit
HouseBlock getLimitedMaximumSubSum(vector<candy_t> array,
                                   candy_t maximumLimit) {
    HouseBlock current = { 0, 0, 0 };
    HouseBlock best = { 0, 0, 0 };

    //find the "maximum" sub array start from current.start
#ifdef WITH_OPENMP
    //with openmp optimization
#pragma omp parallel for reduction(maxOpt:best) firstprivate(current)
#endif
    for (size_t i=0; i<array.size(); i++) {
        //remove the case that starts with home with zero candy
        if(array[i] == 0) {
            continue;
        }

        //init and check current status
        current.start = i;
        if(current.end < current.start) {
            current.end = current.start;
            current.sum = 0;
        }

        //increase the current.end based on the former's "maximum" sub
        //array end position
        while (current.end < array.size()) {
            candy_t sum = current.sum + array[current.end];
            //stop if sum can't grow further or have gotten "maximum" and followed with 0 value.
            if (sum > maximumLimit || (array[current.end] == 0 && sum == maximumLimit))
                break;

            current.sum = sum;
            current.end++;
        }

        //chosing and storing the best result
        if (current.sum > best.sum)
            best = current;

        //update the current statues to use them for the next start
        //position
        if (current.end > current.start)
            current.sum -= array[current.start];
    }

    return best;
}

int main() {
    vector<candy_t> pieces;
    candy_t maximumLimit;

    //read the data from the input file
    inputData("input.txt", pieces, maximumLimit);

    //handle the special cases where parents don't want their kids to have
    //any candy.
    if (maximumLimit == 0) {
        cout << "You are grounded this year. Be a nice kid next year!" << endl;
        return 0;
    }

    //get the sub array
    HouseBlock best = getLimitedMaximumSubSum(pieces, maximumLimit);

    //output result
    if (best.end <= best.start) {
        cout << "Don't go here" << endl;
    } else {
        cout << "Start at home " << best.start + 1 <<
            " and go to home " << best.end <<
            " getting " << best.sum << " pieces of candy" << endl;
    }

    return 0;
}
